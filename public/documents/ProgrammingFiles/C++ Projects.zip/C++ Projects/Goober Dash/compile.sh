qmake WebViewer.pro
make
make clean
./WebViewer
